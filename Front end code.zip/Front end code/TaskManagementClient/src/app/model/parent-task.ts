export class ParentTask {
  id:number;
  parentTask:string;
  

}
