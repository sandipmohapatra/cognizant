/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TaskSearchPipe } from './task-search.pipe';

describe('TaskSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new TaskSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
