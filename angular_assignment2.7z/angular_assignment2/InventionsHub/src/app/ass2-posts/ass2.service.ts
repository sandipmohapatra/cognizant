import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';



@Injectable({
  providedIn: 'root'
})
export class Ass2Service {
  private heroesUrl = 'https://jsonplaceholder.typicode.com/posts';  // URL to web api


  constructor(private http: HttpClient) { }

  getHeroes(): Promise<any> {

    /* this.http.get(this.heroesUrl).subscribe(data => {
       console.log(data);
       return data;
     });*/
    return this.get(this.heroesUrl);
  }

  getHero(id) {
    debugger
    return this.get(this.heroesUrl + '/' + id);
  }




  deleteHero(id): Promise<any> {

    return this.http.delete('https://jsonplaceholder.typicode.com/posts/' + id)
      .toPromise()
      .then(response => { console.log('pravat 123 delete '); console.log(response); return response })
      .catch();
  }



  get(url) {
    return this.http.get(url)
      .toPromise()
      .then(response => { console.log('pravat 123'); console.log(response); return response })
      .catch();
  }



  editHero(hero, id) {
    // return this.http.put(url, JSON.stringify(customer), {headers: this.headers});

    return this.http.put('https://jsonplaceholder.typicode.com/posts/' + id, JSON.stringify(hero))
      .toPromise()
      .then(response => { console.log('pravat 123 delete '); console.log(response); return response })
      .catch();

  }

  createHero(hero) {
    return this.http.post('https://jsonplaceholder.typicode.com/posts', JSON.stringify(hero))
      .toPromise()
      .then(response => { console.log('pravat 123 delete '); console.log(response); return response })
      .catch();
  }

  saveData(postData, id) {

    if (id != undefined && id > 0) {
      return this.editHero(postData, id)
    
    } else {
      return this.createHero(postData);
    }

  }










  /* return [

     { "id": 10, "firstName": "Sathish", "lastName": "Kotha" },

     { "id": 11, "firstName": "Ramesh", "lastName": "Kotha" },

     { "id": 12, "firstName": "Ragav", "lastName": "Raju" },
     { "id": 12, "firstName": "Ragav", "lastName": "Raju" }

   ];*/



}
