import { Component, OnInit } from '@angular/core';
import { Ass2Service } from './ass2.service';
import post from './post'
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-ass2-posts',
  templateUrl: './ass2-posts.component.html',
  styleUrls: ['./ass2-posts.component.css']
})
export class Ass2PostsComponent implements OnInit {



  posts = [];

  constructor(private ass2Service: Ass2Service) { }

  ngOnInit() {
    this.getPosts()
  }

  getPosts(): void {
    this.ass2Service.getHeroes().then(posts => this.posts = posts);;
  }

  onDelete(id: number): void {
    this.ass2Service.deleteHero(id).then(response => {

      this.getPosts();
    });;
  }

}
