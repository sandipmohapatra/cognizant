import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeroesComponent } from './heroes/heroes.component';
import { FormsModule } from '@angular/forms';
import { HeroDetailComponent } from './hero-detail/hero-detail.component';
import { AppRoutingModule } from './/app-routing.module';
import { WelcomeComponent } from './welcome/welcome.component';
import { ServicesComponent } from './services/services.component';
import { ContactComponent } from './contact/contact.component';
import { ClientComponent } from './client/client.component';
import { AboutComponent } from './about/about.component';
import { MyHeroDetailComponent } from './my-hero-detail/my-hero-detail.component';
import { Ass2PostsComponent } from './ass2-posts/ass2-posts.component';
import { HttpClientModule } from '@angular/common/http';
import { PostEditComponent } from './ass2-posts/post-edit.component'; 

@NgModule({
  declarations: [
    AppComponent,
    HeroesComponent,
    HeroDetailComponent,
    WelcomeComponent,
    ServicesComponent,
    ContactComponent,
    ClientComponent,
    AboutComponent,
    MyHeroDetailComponent,
    Ass2PostsComponent,
    PostEditComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
