import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import Hero from '../hero';
import { Location } from '@angular/common';

@Component({
  selector: 'app-my-hero-detail',
  templateUrl: './my-hero-detail.component.html',
  styleUrls: ['./my-hero-detail.component.css']
})
export class MyHeroDetailComponent implements OnInit {
  @Input() hero: Hero;
  id;
  constructor(private route: ActivatedRoute,
    private location: Location) {



  }

  ngOnInit() {
    let id = this.route.snapshot.paramMap.get('id');
    this.id=id;
    alert(id);
  }

  
  goBack(): void {
    this.location.back();
  }

}
