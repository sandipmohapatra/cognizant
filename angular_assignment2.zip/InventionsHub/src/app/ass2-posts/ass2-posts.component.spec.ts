import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ass2PostsComponent } from './ass2-posts.component';

describe('Ass2PostsComponent', () => {
  let component: Ass2PostsComponent;
  let fixture: ComponentFixture<Ass2PostsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ass2PostsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ass2PostsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
