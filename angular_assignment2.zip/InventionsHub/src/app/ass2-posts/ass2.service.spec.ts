import { TestBed, inject } from '@angular/core/testing';

import { Ass2Service } from './ass2.service';

describe('Ass2Service', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Ass2Service]
    });
  });

  it('should be created', inject([Ass2Service], (service: Ass2Service) => {
    expect(service).toBeTruthy();
  }));
});
