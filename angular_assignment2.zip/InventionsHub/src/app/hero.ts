export default class Hero {

  id: number;
    name: string;
}