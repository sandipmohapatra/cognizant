import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HeroesComponent } from './heroes/heroes.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ServicesComponent } from './services/services.component';
import { ContactComponent } from './contact/contact.component';
import { ClientComponent}  from './client/client.component';
import { AboutComponent } from './about/about.component';
import {MyHeroDetailComponent} from './my-hero-detail/my-hero-detail.component';
import { Ass2PostsComponent } from './ass2-posts/ass2-posts.component';
import { PostEditComponent } from './ass2-posts/post-edit.component'; 

const routes: Routes = [
  { path: '', component: HeroesComponent, pathMatch: 'full' },
  { path: 'heroes', component: HeroesComponent },
  { path: 'welcome', component: WelcomeComponent },
  { path: 'service', component: ServicesComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'client', component: ClientComponent },
  { path: 'about', component: AboutComponent },
  { path: 'detail/:id', component: MyHeroDetailComponent },

  { path: 'assign2', component: Ass2PostsComponent },
  
  { path: 'assign2/:id', component: PostEditComponent }



];



@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes),

  ],
  exports: [RouterModule],
  // declarations: [RouterModule]
})


export class AppRoutingModule { }
